# Loan Approval Prediction — Flask Backend

A Flask web app that serves a form, runs a pre-trained Keras neural network,
and shows **Loan Approved / Loan Rejected** with a confidence percentage.

## Project structure

```
loan_approval_app/
├── app.py                # Flask backend
├── requirements.txt
├── templates/
│   └── index.html        # Form + result page
├── loan_model.keras      # <-- put your trained model here
├── scaler.pkl            # <-- put your fitted scaler here
└── label_encoders.pkl    # <-- put your fitted label encoders here
```

## 1. Add your trained artifacts

Copy your three training outputs into the project root (same folder as
`app.py`):

- `loan_model.keras` — the trained Keras model
- `scaler.pkl` — the fitted scaler (e.g. `StandardScaler`/`MinMaxScaler`),
  saved with `pickle.dump(scaler, open("scaler.pkl", "wb"))`
- `label_encoders.pkl` — a dict of `{column_name: fitted LabelEncoder}`,
  saved with `pickle.dump(label_encoders, open("label_encoders.pkl", "wb"))`

## 2. Match the column setup to YOUR training notebook

`app.py` assumes the classic "Loan Prediction" dataset schema:

- Categorical: `Gender`, `Married`, `Dependents`, `Education`,
  `Self_Employed`, `Property_Area`
- Numerical: `ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`,
  `Loan_Amount_Term`, `Credit_History`

At the top of `app.py`, `CATEGORICAL_COLUMNS`, `NUMERICAL_COLUMNS`, and
`FEATURE_ORDER` control preprocessing. **`FEATURE_ORDER` must exactly match
the column order used when you called `scaler.fit(...)` during training.**
If your notebook used different columns or order, update these three lists
to match — this is the single most common source of "the model gives weird
predictions" bugs, since a scaler/model doesn't know column *names*, only
column *position*.

The app currently assumes the model's output layer is a single sigmoid unit
(probability of approval). If your model instead outputs two-class softmax
probabilities, adjust the `probability = ...` line in the `/predict` route
in `app.py` accordingly (e.g. `probability = raw_prediction[0][1]`).

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 4. Run

```bash
python app.py
```

Then open http://127.0.0.1:5000 in your browser.

## Error handling included

- If `loan_model.keras`, `scaler.pkl`, or `label_encoders.pkl` fail to
  load at startup, the home page shows a clear configuration-error banner
  instead of crashing.
- Missing form fields, non-numeric numeric fields, and categorical values
  the label encoder has never seen are caught and shown to the user
  (HTTP 400) instead of raising a stack trace.
- Any unexpected error during prediction is caught, logged to the server
  console with a full traceback, and shown to the user as a generic
  message (HTTP 500).
