"""
Flask backend for Loan Approval Prediction Using Neural Networks.

This app:
    1. Loads a pre-trained Keras neural network (loan_model.keras)
    2. Loads the fitted scaler (scaler.pkl) and label encoders (label_encoders.pkl)
       that were saved during training.
    3. Serves an HTML form on the home page ("/").
    4. Accepts the form submission on "/predict", pre-processes the input
       EXACTLY the way the training data was pre-processed, runs the model,
       and renders the result (Approved / Rejected + confidence %).

Expected dataset schema (standard "Loan Prediction" dataset). Adjust the
CATEGORICAL_COLUMNS / NUMERICAL_COLUMNS / FEATURE_ORDER lists below if your
training notebook used a different set/order of columns.
"""

import os
import pickle
import traceback

import numpy as np
from flask import Flask, render_template, request

# TensorFlow / Keras is imported lazily-safe: if it's missing the app will
# still start and show a clear error on the predict route instead of crashing
# on import.
try:
    from tensorflow.keras.models import load_model
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "TensorFlow is required to run this app. Install it with "
        "`pip install tensorflow`."
    ) from exc

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(APP_DIR, "loan_model.keras")
SCALER_PATH = os.path.join(APP_DIR, "scaler.pkl")
ENCODERS_PATH = os.path.join(APP_DIR, "label_encoders.pkl")

# Columns that were label-encoded during training (categorical features).
CATEGORICAL_COLUMNS = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "Property_Area",
]

# Columns that are already numeric.
NUMERICAL_COLUMNS = [
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
    "Credit_History",
]

# The exact column order the model was trained on. This MUST match the
# order of columns used when `scaler.fit()` / `model.fit()` were called.
# Update this list to match your training notebook if it differs.
FEATURE_ORDER = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
    "Credit_History",
    "Property_Area",
]

# --------------------------------------------------------------------------- #
# Flask app + artifact loading
# --------------------------------------------------------------------------- #

app = Flask(__name__)

model = None
scaler = None
label_encoders = None
load_error = None  # Stores a human-readable message if loading failed.


def load_artifacts():
    """
    Load the trained model, scaler, and label encoders from disk.

    Any failure here is captured (not raised) so the Flask app can still
    start up and show a friendly error message on the web page instead of
    crashing the whole server.
    """
    global model, scaler, label_encoders, load_error

    try:
        model = load_model(MODEL_PATH)
    except Exception as exc:
        load_error = f"Failed to load model from '{MODEL_PATH}': {exc}"
        return

    try:
        with open(SCALER_PATH, "rb") as f:
            scaler = pickle.load(f)
    except Exception as exc:
        load_error = f"Failed to load scaler from '{SCALER_PATH}': {exc}"
        return

    try:
        with open(ENCODERS_PATH, "rb") as f:
            label_encoders = pickle.load(f)
    except Exception as exc:
        load_error = f"Failed to load label encoders from '{ENCODERS_PATH}': {exc}"
        return


load_artifacts()


# --------------------------------------------------------------------------- #
# Pre-processing helpers
# --------------------------------------------------------------------------- #

def encode_categorical(column_name, raw_value):
    """
    Encode a single categorical value using the LabelEncoder that was fit
    for that column during training.

    Raises a ValueError with a clear message if the value was never seen
    during training (the encoder cannot map it to a known class).
    """
    encoder = label_encoders.get(column_name)
    if encoder is None:
        raise ValueError(f"No label encoder found for column '{column_name}'.")

    try:
        # LabelEncoder.transform expects an array-like input.
        encoded_value = encoder.transform([raw_value])[0]
    except ValueError:
        valid_options = list(encoder.classes_)
        raise ValueError(
            f"Invalid value '{raw_value}' for '{column_name}'. "
            f"Expected one of: {valid_options}."
        )
    return encoded_value


def preprocess_form_data(form):
    """
    Convert the raw Flask form submission into a single, scaled feature
    row (numpy array) ready to be fed to the neural network.

    Steps mirror training-time preprocessing:
        1. Read raw values from the form.
        2. Label-encode categorical columns using the saved encoders.
        3. Cast numerical columns to float.
        4. Assemble the row in FEATURE_ORDER.
        5. Scale the full row using the saved scaler.
    """
    row = {}

    # --- Categorical fields --------------------------------------------- #
    for col in CATEGORICAL_COLUMNS:
        raw_value = form.get(col)
        if raw_value is None or raw_value == "":
            raise ValueError(f"Missing required field: '{col}'.")
        row[col] = encode_categorical(col, raw_value)

    # --- Numerical fields -------------------------------------------------#
    for col in NUMERICAL_COLUMNS:
        raw_value = form.get(col)
        if raw_value is None or raw_value == "":
            raise ValueError(f"Missing required field: '{col}'.")
        try:
            row[col] = float(raw_value)
        except ValueError:
            raise ValueError(f"'{col}' must be a number, got '{raw_value}'.")

    # --- Assemble in the correct column order ---------------------------- #
    ordered_values = [row[col] for col in FEATURE_ORDER]
    feature_array = np.array(ordered_values, dtype=np.float32).reshape(1, -1)

    # --- Scale -------------------------------------------------------------#
    scaled_array = scaler.transform(feature_array)

    return scaled_array


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #

@app.route("/", methods=["GET"])
def home():
    """Render the loan application input form."""
    return render_template(
        "index.html",
        load_error=load_error,
        categorical_columns=CATEGORICAL_COLUMNS,
        label_encoders=label_encoders,
    )


@app.route("/predict", methods=["POST"])
def predict():
    """
    Handle the form submission:
        1. Validate that the model/scaler/encoders loaded correctly.
        2. Pre-process the submitted form data.
        3. Run the neural network to get a prediction probability.
        4. Render the result page with Approved/Rejected + confidence %.
    """
    # Guard: artifacts failed to load at startup.
    if load_error:
        return render_template("index.html", load_error=load_error), 500

    try:
        features = preprocess_form_data(request.form)

        # Run inference. Output is assumed to be a single sigmoid probability
        # (shape (1, 1)) representing P(Loan Approved).
        raw_prediction = model.predict(features, verbose=0)
        probability = float(np.ravel(raw_prediction)[0])

        approved = probability >= 0.5
        confidence = probability if approved else (1 - probability)

        result = {
            "decision": "Loan Approved" if approved else "Loan Rejected",
            "approved": approved,
            "confidence": round(confidence * 100, 2),
        }

        return render_template(
            "index.html",
            result=result,
            categorical_columns=CATEGORICAL_COLUMNS,
            label_encoders=label_encoders,
            form_data=request.form,
        )

    except ValueError as ve:
        # Expected, user-facing validation errors (bad/missing input).
        return render_template(
            "index.html",
            error=str(ve),
            categorical_columns=CATEGORICAL_COLUMNS,
            label_encoders=label_encoders,
            form_data=request.form,
        ), 400

    except Exception as exc:
        # Unexpected server-side errors: log full traceback, show a generic
        # message to the user.
        traceback.print_exc()
        return render_template(
            "index.html",
            error=f"An unexpected error occurred while predicting: {exc}",
            categorical_columns=CATEGORICAL_COLUMNS,
            label_encoders=label_encoders,
            form_data=request.form,
        ), 500


@app.errorhandler(404)
def not_found(_):
    return render_template("index.html", error="Page not found."), 404


@app.errorhandler(500)
def server_error(_):
    return render_template("index.html", error="Internal server error."), 500


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #

if __name__ == "__main__":
    # debug=True is convenient during development; turn off in production.
    app.run(debug=True)
